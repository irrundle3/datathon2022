import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
#%matplotlib inline
from urllib.request import urlopen
from bs4 import BeautifulSoup

from vega_datasets import data
import math
import streamlit as st


def webscrape (link):
  url = f"https://www.ndbc.noaa.gov/data/realtime2/{link}.txt"
  html = urlopen(url)

  soup = BeautifulSoup(html, 'html.parser')
  type(soup)

  text = soup.get_text()

  text_list=text.split(' ')

  text_list = [value for value in text_list if value != '']
  text_list_copy = []
  for i in range(len(text_list)):
    if ('\n') in text_list[i]:
      temp = text_list[i].split('\n')
      for j in temp:
        text_list_copy.append(j)
    else:
      text_list_copy.append(text_list[i])

  index = []
  count =int(len(text_list_copy)/19)
  for i in range(count):
      index.append(i)

  column = []
  for i in range(19):
      column.append(text_list_copy[i]+' '+link)

  entries = []
  counter = 0
  for a in range(len(index)):
    temp = []
    for b in range(19):
      temp.append(text_list_copy[counter])
      counter+=1
    entries.append(temp)
  df = pd.DataFrame(
      entries,

      index,

      column,

  )
  return df

def clean(link):
  name = webscrape(link)
  name[f"Time {link}"] = name[f"#YY {link}"]+" " +name[f"MM {link}"] + " " +name[f"DD {link}"] + " " +name[f"hh {link}"]
  name = name.drop(columns=[f"mm {link}", f"#YY {link}", f"MM {link}",f"DD {link}"])
  columns_titles = [f"Time {link}",f"hh {link}",f"WDIR {link}", f"WSPD {link}"]
  name=name.reindex(columns=columns_titles)
  name = name.iloc[1: , :]
  name = name.iloc[1: , :]
  return name

def drop_repeat(link):

  name = clean(link)
  name_copy=name.copy(deep=True)

  current_hour = name.at[2 , f'hh {link}']

  for ind in range(3,len(name)):

    if current_hour == name.at[ind , f'hh {link}']:
      name_copy = name_copy.drop(ind)
    else:
      current_hour = name.at[ind , f'hh {link}']
  name_copy = name_copy.drop(columns=[f"hh {link}"])

  return name_copy
  #return name

fi=drop_repeat('KATP')
fi

def before_jan(date):
  date = date.split()
  result = int(date[0])*365*24+int(date[1])*31*24+int(date[2])*24+int(date[3])
  chop_off = 17714159

  if result > chop_off:
    return True
  else:
    return False


def after_dec(date):
  date = date.split()
  result = int(date[0])*365*24+int(date[1])*31*24+int(date[2])*24+int(date[3])
  chop_off = 17713272
  if result < chop_off:
    return True
  else:
    return False

def compare(link):
  name = drop_repeat(link)
  for i, row in name.iterrows():
    if before_jan(name.at[i , f"Time {link}"]):
      name = name.drop(i)
    else:
      break
  for a, b in name[::-1].iterrows():
    if after_dec(name.at[i , f"Time {link}"]):
      name = name.drop(i)
    else:
      break
  return name

def vector(link):
  name = compare(link)
  name = name.replace("MM", np.nan)
  name[f"North {link}"] = np.cos(np.pi / 180.0 * name[f'WDIR {link}'].astype(float)) * (name[f"WSPD {link}"].astype(float))
  name[f"East {link}"] = np.sin(np.pi / 180.0 * name[f'WDIR {link}'].astype(float)) * (name[f"WSPD {link}"].astype(float))
  name.drop(f'WDIR {link}',axis='columns', inplace=True)
  name.drop(f'WSPD {link}',axis='columns', inplace=True)
  #name.drop(f'hh {link}',axis='columns', inplace=True)
  name = name.interpolate()
  return name

ejfi = vector('KBQX')
ejfi

import math
def make_goddict(list):
  master={}
  for input in list:
    master[input] = vector(input)
  return master

result=make_goddict(['KIKT','KBQX','KMIS'])
result

import warnings
import itertools
import numpy as np
import matplotlib.pyplot as plt
warnings.filterwarnings("ignore")
plt.style.use('fivethirtyeight')
import pandas as pd
import statsmodels.api as sm
import matplotlib

matplotlib.rcParams['axes.labelsize'] = 14
matplotlib.rcParams['xtick.labelsize'] = 12
matplotlib.rcParams['ytick.labelsize'] = 12
matplotlib.rcParams['text.color'] = 'k'


def daysumofmonthsbefore(month):
  if month == 1:
    return 0
  elif month == 2:
    return 31
  elif month == 3:
    return 59
  elif month == 4:
    return 90
  elif month == 5:
    return 120
  elif month == 6:
    return 151
  elif month == 7:
    return 181
  elif month == 8:
    return 212
  elif month == 9:
    return 243
  elif month == 10:
    return 273
  elif month == 11:
    return 304
  else:
    return 334
def jesus_hours(date):
  date = date.split()
  return (int(date[0])-2021)*365*24+daysumofmonthsbefore(int(date[1]))*24+int(date[2])*24+int(date[3])

result=make_goddict(['KIKT','KBQX','KMIS'])
for link in result.keys():
  result[link][f"Time {link}"] = result[link][f"Time {link}"].apply(jesus_hours)
  result[link] = result[link].set_index(f"Time {link}")
  result[link].plot(figsize=(15,6))

import numpy as np
from sklearn.linear_model import LinearRegression
test = result['KMIS']
#print(test)
inputs = []
north_outputs = []
east_outputs = []
print(test)
testdict = test.to_dict()
print(testdict['North KMIS'])
for idx in range(9455, 8500, -1):
  input = []
  for i in range(1,5):
    input.append(testdict['North KMIS'][idx-25*i])
    input.append(testdict['East KMIS'][idx-25*i])
  inputs.append(input)
  north_outputs.append(testdict['North KMIS'][idx])
  east_outputs.append(testdict['East KMIS'][idx])
inputs, north_outputs, east_outputs = np.array(inputs), np.array(north_outputs), np.array(east_outputs)

north_model = LinearRegression().fit(inputs, north_outputs)
east_model = LinearRegression().fit(inputs, east_outputs)
north_r_sq = north_model.score(inputs, north_outputs)
east_r_sq = east_model.score(inputs, east_outputs)
print('r^2 = ' + str(north_r_sq))
print('intercept ' + str(north_model.intercept_))
print('slope', north_model.coef_)

rand_input = np.array([[12, 12, 24, 16, 15, 35, 24, 23]])
north_pred = north_model.predict(rand_input)
east_pred = east_model.predict(rand_input)
print(north_pred, east_pred)

north_predictions = testdict['North KMIS'].copy()
east_predictions = testdict['East KMIS'].copy()

print(north_predictions)

north_predictions_max = max(north_predictions.keys())
east_predictions_max = max(east_predictions.keys())

rows = 9455
for i in range(72):
  past_values = []
  for j in range(1,5):
    past_values.append(north_predictions[rows-25*j])
    past_values.append(east_predictions[rows-25*j])
  north_predictions[north_predictions_max + i + 1] = north_model.predict([past_values])[0]
  east_predictions[east_predictions_max + i + 1] = east_model.predict([past_values])[0]
print(testdict['North KMIS'])
print(north_predictions)

import matplotlib.pylab as plt

my_dict = north_predictions
myList = my_dict.items()
myList = sorted(myList)
x, y = zip(*myList)

plt.plot(x, y)
plt.show()
st.pyplot(fig=None)
fig, ax = plt.subplots()
ax.plot(x, y)

st.pyplot(fig)
#st.line_chart()



#########################################################################################



#DATE_COLUMN = 'date/time'
#DATA_URL = ('https://s3-us-west-2.amazonaws.com/'
#            'streamlit-demo-data/uber-raw-data-sep14.csv.gz')

#@st.cache
#def load_data(nrows):
#    data = pd.read_csv(DATA_URL, nrows=nrows)
#    lowercase = lambda x: str(x).lower()
#    data.rename(lowercase, axis='columns', inplace=True)
#    data[DATE_COLUMN] = pd.to_datetime(data[DATE_COLUMN])
#    return data

#data_load_state = st.text('Loading data...')
#data = pred_ci
#data_load_state.text("Done! (using st.cache)")

#if st.checkbox('Show raw data'):
#    st.subheader('Raw data')
#    st.write(data)

#st.subheader('Number of pickups by hour')
#hist_values = np.histogram(data[DATE_COLUMN].dt.hour, bins=24, range=(0,24))[0]
#st.bar_chart(hist_values)

# Some number in the range 0-23
#hour_to_filter = st.slider('hour', 0, 23, 17)
#filtered_data = data[data[DATE_COLUMN].dt.hour == hour_to_filter]

#st.subheader('Map of all pickups at %s:00' % hour_to_filter)
#st.map(filtered_data)
